arm-none-eabi-gdb -se _build/nrf52832_xxaa.out -tui -x gdb.cmd
