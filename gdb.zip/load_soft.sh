arm-none-eabi-gdb -se ../SDK/examples/dfu/bootloader_secure_ble/pca10040_debug/hex/secure_dfu_ble_s132_pca10040_debug.hex -tui -x gdb.cmd
